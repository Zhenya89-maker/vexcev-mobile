# Правила ProGuard/R8 для Vexcev Mobile.
# Compose и AndroidX поставляют свои consumer-правила; дополнительных правил не требуется.
