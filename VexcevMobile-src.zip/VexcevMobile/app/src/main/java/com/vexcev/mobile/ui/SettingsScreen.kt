package com.vexcev.mobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vexcev.mobile.BuildConfig
import com.vexcev.mobile.config.LauncherConfig
import com.vexcev.mobile.ui.theme.VexcevColors.Black
import com.vexcev.mobile.ui.theme.VexcevColors.Orange
import com.vexcev.mobile.ui.theme.VexcevColors.PanelElevated
import com.vexcev.mobile.ui.theme.VexcevColors.TextPrimary
import com.vexcev.mobile.ui.theme.VexcevColors.TextSecondary

@Composable
fun SettingsScreen(vm: LauncherViewModel, modifier: Modifier) {
    val verify by vm.verifyOnStart.collectAsStateWithLifecycle()
    val checkServer by vm.checkServerOnStart.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        VexcevPanel {
            SectionTitle("ЗАПУСК")
            SettingSwitch(
                title = "Проверять целостность ресурсов при запуске",
                checked = verify,
                onChange = vm::setVerifyOnStart
            )
            SettingSwitch(
                title = "Проверять доступность сервера при запуске",
                checked = checkServer,
                onChange = vm::setCheckServerOnStart
            )
        }

        VexcevPanel {
            SectionTitle("О ЛАУНЧЕРЕ")
            InfoRow("Версия", BuildConfig.VERSION_NAME)
            InfoRow("Сервер", "${LauncherConfig.SERVER_HOST}:${LauncherConfig.SERVER_PORT}")
            InfoRow("Игровой клиент", if (vm.gameClientInstalled) "подключён" else "не подключён")
            InfoRow(
                "Загрузка ресурсов",
                if (LauncherConfig.RESOURCE_MANIFEST_URL == null) "не настроена" else "HTTPS"
            )
        }
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Black,
                checkedTrackColor = Orange,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = PanelElevated
            )
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 13.sp)
        Text(value, color = TextPrimary, fontSize = 13.sp)
    }
}
