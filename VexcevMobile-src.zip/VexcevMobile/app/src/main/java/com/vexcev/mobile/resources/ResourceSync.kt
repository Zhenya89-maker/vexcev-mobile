package com.vexcev.mobile.resources

import com.vexcev.mobile.net.HttpsClient
import com.vexcev.mobile.net.LauncherException
import com.vexcev.mobile.net.toUserMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.File

/**
 * ПРЕДВАРИТЕЛЬНАЯ схема манифеста ресурсов. Формат НЕ подтверждён сервером
 * и должен быть заменён на реальный, когда он будет известен:
 *
 * { "files": [ { "path": "relative/file.ext", "url": "https://...", "sha256": "<64 hex>", "size": 123 } ] }
 */
data class ResourceEntry(val path: String, val url: String, val sha256: String, val size: Long)

data class SyncProgress(
    val percent: Int,
    val currentFile: String,
    val filesDone: Int,
    val filesTotal: Int
)

sealed interface SyncResult {
    data object NotConfigured : SyncResult
    data class Ok(val files: Int, val downloaded: Int) : SyncResult
    data class Failed(val message: String) : SyncResult
}

object ManifestParser {
    private val sha256Pattern = Regex("^[0-9a-fA-F]{64}$")

    fun parse(json: String): List<ResourceEntry> {
        try {
            val files = JSONObject(json).optJSONArray("files")
                ?: throw LauncherException("В манифесте отсутствует список files.")
            return List(files.length()) { i ->
                val item = files.getJSONObject(i)
                val path = item.optString("path")
                validatePath(path)
                val url = item.optString("url")
                HttpsClient.requireHttps(url)
                val sha = item.optString("sha256")
                if (!sha256Pattern.matches(sha)) {
                    throw LauncherException("Некорректная контрольная сумма для $path.")
                }
                val size = item.optLong("size", -1L)
                if (size < 0) throw LauncherException("Некорректный размер файла $path.")
                ResourceEntry(path, url, sha.lowercase(), size)
            }
        } catch (e: JSONException) {
            throw LauncherException("Манифест ресурсов повреждён (ожидался корректный JSON).", e)
        }
    }

    private fun validatePath(path: String) {
        if (path.isBlank() || path.startsWith("/") || path.contains("..") || path.contains('\\')) {
            throw LauncherException("Недопустимый путь в манифесте: '$path'.")
        }
    }
}

/** Синхронизация игровых ресурсов: загрузка, проверка SHA-256 и прогресс. */
class ResourceSync(private val rootDir: File) {

    suspend fun run(
        manifestUrl: String?,
        onProgress: (SyncProgress) -> Unit
    ): SyncResult = withContext(Dispatchers.IO) {
        if (manifestUrl.isNullOrBlank()) return@withContext SyncResult.NotConfigured
        try {
            val entries = ManifestParser.parse(HttpsClient.fetchText(manifestUrl))
            val totalBytes = entries.sumOf { it.size }.coerceAtLeast(1L)
            var doneBytes = 0L
            var downloaded = 0

            entries.forEachIndexed { index, entry ->
                val target = safeTarget(entry.path)
                val upToDate = target.isFile && HttpsClient.sha256File(target) == entry.sha256
                if (upToDate) {
                    doneBytes += entry.size
                    onProgress(progress(doneBytes, totalBytes, entry.path, index, entries.size))
                } else {
                    HttpsClient.downloadVerified(entry.url, target, entry.sha256) { delta ->
                        doneBytes += delta
                        onProgress(progress(doneBytes, totalBytes, entry.path, index, entries.size))
                    }
                    downloaded++
                }
            }
            SyncResult.Ok(files = entries.size, downloaded = downloaded)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SyncResult.Failed(e.toUserMessage())
        }
    }

    private fun progress(done: Long, total: Long, file: String, index: Int, count: Int) =
        SyncProgress(
            percent = ((done * 100) / total).toInt().coerceIn(0, 100),
            currentFile = file,
            filesDone = index,
            filesTotal = count
        )

    /** Не даёт манифесту записать файл за пределами папки игры. */
    private fun safeTarget(path: String): File {
        val root = rootDir.canonicalFile
        val target = File(root, path).canonicalFile
        if (!target.path.startsWith(root.path + File.separator)) {
            throw LauncherException("Путь вне папки игры: '$path'.")
        }
        return target
    }
}
