package com.vexcev.mobile.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.vexcev.mobile.ui.theme.VexcevColors

@Composable
fun LauncherApp(vm: LauncherViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Главная" to Icons.Filled.Home,
        "Профиль" to Icons.Filled.Person,
        "Настройки" to Icons.Filled.Settings
    )

    Scaffold(
        containerColor = VexcevColors.Black,
        bottomBar = {
            NavigationBar(containerColor = VexcevColors.Panel) {
                tabs.forEachIndexed { index, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VexcevColors.Black,
                            selectedTextColor = VexcevColors.Orange,
                            indicatorColor = VexcevColors.Orange,
                            unselectedIconColor = VexcevColors.TextSecondary,
                            unselectedTextColor = VexcevColors.TextSecondary
                        )
                    )
                }
            }
        }
    ) { inner ->
        val modifier = Modifier.padding(inner)
        when (tab) {
            0 -> HomeScreen(vm, modifier)
            1 -> ProfileScreen(vm, modifier)
            else -> SettingsScreen(vm, modifier)
        }
    }
}
