package com.vexcev.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.vexcev.mobile.ui.LauncherApp
import com.vexcev.mobile.ui.LauncherViewModel
import com.vexcev.mobile.ui.theme.VexcevTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VexcevTheme {
                LauncherApp(viewModel)
            }
        }
    }
}
