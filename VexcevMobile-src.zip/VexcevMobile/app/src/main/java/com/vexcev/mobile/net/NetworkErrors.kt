package com.vexcev.mobile.net

import org.json.JSONException
import java.io.FileNotFoundException
import java.io.IOException
import java.net.ConnectException
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/** Ошибка, текст которой можно показать пользователю как есть. */
class LauncherException(message: String, cause: Throwable? = null) : Exception(message, cause)

fun Throwable.toUserMessage(): String = when (this) {
    is LauncherException -> message ?: "Неизвестная ошибка лаунчера."
    is UnknownHostException -> "Не удалось найти сервер. Проверьте интернет-соединение и адрес."
    is SocketTimeoutException -> "Превышено время ожидания ответа. Попробуйте позже."
    is ConnectException -> "Не удалось подключиться к серверу. Возможно, сервер выключен."
    is SSLException -> "Ошибка защищённого соединения (HTTPS). Проверьте дату и время на устройстве."
    is MalformedURLException -> "Некорректный адрес загрузки."
    is FileNotFoundException -> "Файл не найден на сервере."
    is JSONException -> "Ответ сервера повреждён (ожидался JSON)."
    is IOException -> "Сетевая ошибка: ${message ?: "соединение прервано"}."
    else -> "Непредвиденная ошибка: ${message ?: javaClass.simpleName}."
}
