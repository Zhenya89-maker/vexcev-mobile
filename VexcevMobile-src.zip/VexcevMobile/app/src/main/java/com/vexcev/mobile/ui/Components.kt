package com.vexcev.mobile.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vexcev.mobile.ui.theme.VexcevColors.Orange
import com.vexcev.mobile.ui.theme.VexcevColors.Panel
import com.vexcev.mobile.ui.theme.VexcevColors.Stroke
import com.vexcev.mobile.ui.theme.VexcevColors.TextPrimary

@Composable
fun VexcevLogo(modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = Orange, fontWeight = FontWeight.Black)) { append("VEXCEV") }
                withStyle(SpanStyle(color = TextPrimary, fontWeight = FontWeight.Light)) { append(" MOBILE") }
            },
            fontSize = 30.sp,
            letterSpacing = 3.sp
        )
        Box(
            Modifier
                .padding(top = 6.dp)
                .size(width = 80.dp, height = 3.dp)
                .background(Orange)
        )
    }
}

@Composable
fun VexcevPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Panel)
            .border(1.dp, Stroke, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        color = Orange,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        letterSpacing = 1.sp
    )
}
