package com.vexcev.mobile.config

/**
 * Настройки лаунчера в одном месте.
 *
 * Адреса Maze-Tech из старого APK намеренно не используются.
 * null означает «не настроено»: лаунчер не выдумывает адреса и
 * честно показывает статус в интерфейсе.
 */
object LauncherConfig {
    const val SERVER_NAME = "Основной сервер"
    const val SERVER_HOST = "82.47.171.239"
    const val SERVER_PORT = 7903
    const val CONNECT_TIMEOUT_MS = 5_000

    /** HTTPS-адрес манифеста игровых ресурсов. Пока не известен — null. */
    val RESOURCE_MANIFEST_URL: String? = null

    /** HTTPS-адрес JSON-ленты новостей. Пока не известен — null. */
    val NEWS_URL: String? = null
}
