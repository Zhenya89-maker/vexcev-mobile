package com.vexcev.mobile.settings

import android.content.Context
import androidx.core.content.edit

class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("vexcev_settings", Context.MODE_PRIVATE)

    var nickname: String
        get() = prefs.getString(KEY_NICKNAME, "").orEmpty()
        set(value) = prefs.edit { putString(KEY_NICKNAME, value.take(16)) }

    var verifyOnStart: Boolean
        get() = prefs.getBoolean(KEY_VERIFY_ON_START, true)
        set(value) = prefs.edit { putBoolean(KEY_VERIFY_ON_START, value) }

    var checkServerOnStart: Boolean
        get() = prefs.getBoolean(KEY_CHECK_SERVER_ON_START, true)
        set(value) = prefs.edit { putBoolean(KEY_CHECK_SERVER_ON_START, value) }

    private companion object {
        const val KEY_NICKNAME = "nickname"
        const val KEY_VERIFY_ON_START = "verify_on_start"
        const val KEY_CHECK_SERVER_ON_START = "check_server_on_start"
    }
}
