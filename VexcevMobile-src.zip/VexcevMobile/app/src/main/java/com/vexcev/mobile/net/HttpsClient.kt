package com.vexcev.mobile.net

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.security.MessageDigest

/** Минимальный HTTPS-клиент лаунчера на стандартном HttpURLConnection. */
object HttpsClient {

    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 30_000
    private const val MAX_TEXT_BYTES = 2 * 1024 * 1024

    fun requireHttps(url: String): URL {
        val parsed = try {
            URL(url)
        } catch (e: MalformedURLException) {
            throw LauncherException("Некорректный адрес: $url", e)
        }
        if (!parsed.protocol.equals("https", ignoreCase = true)) {
            throw LauncherException("Разрешена загрузка только по HTTPS.")
        }
        return parsed
    }

    private fun open(url: URL): HttpURLConnection {
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = CONNECT_TIMEOUT_MS
        conn.readTimeout = READ_TIMEOUT_MS
        conn.requestMethod = "GET"
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "VexcevMobile/1.0")

        val code = conn.responseCode
        if (code !in 200..299) {
            conn.disconnect()
            throw LauncherException(
                if (code == 404) "Файл не найден на сервере (HTTP 404)."
                else "Сервер вернул ошибку HTTP $code."
            )
        }
        if (!conn.url.protocol.equals("https", ignoreCase = true)) {
            conn.disconnect()
            throw LauncherException("Сервер перенаправил загрузку на небезопасный адрес.")
        }
        return conn
    }

    /** Загружает текст (например, манифест) с ограничением размера. */
    fun fetchText(url: String): String {
        val conn = open(requireHttps(url))
        try {
            conn.inputStream.use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8 * 1024)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > MAX_TEXT_BYTES) throw LauncherException("Ответ сервера слишком большой.")
                    out.write(buffer, 0, n)
                }
                return out.toString(Charsets.UTF_8.name())
            }
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Скачивает файл во временный .part, проверяет SHA-256 и только затем
     * атомарно заменяет целевой файл. При несовпадении хеша файл не сохраняется.
     */
    fun downloadVerified(
        url: String,
        destination: File,
        expectedSha256: String,
        onBytes: (Long) -> Unit
    ) {
        val conn = open(requireHttps(url))
        destination.parentFile?.mkdirs()
        val part = File(destination.parentFile, destination.name + ".part")
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            conn.inputStream.use { input ->
                FileOutputStream(part).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        digest.update(buffer, 0, n)
                        onBytes(n.toLong())
                    }
                }
            }
            val actual = digest.digest().toHex()
            if (!actual.equals(expectedSha256, ignoreCase = true)) {
                throw LauncherException(
                    "Файл ${destination.name} повреждён при загрузке: контрольная сумма не совпадает."
                )
            }
            if (destination.exists() && !destination.delete()) {
                throw LauncherException("Не удалось заменить файл ${destination.name}.")
            }
            if (!part.renameTo(destination)) {
                throw LauncherException("Не удалось сохранить файл ${destination.name}.")
            }
        } catch (e: Throwable) {
            part.delete()
            throw e
        } finally {
            conn.disconnect()
        }
    }

    fun sha256File(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().toHex()
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
