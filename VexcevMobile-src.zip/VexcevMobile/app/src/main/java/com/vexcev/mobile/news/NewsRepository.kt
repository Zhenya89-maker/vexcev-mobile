package com.vexcev.mobile.news

import com.vexcev.mobile.net.HttpsClient
import com.vexcev.mobile.net.toUserMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

data class NewsItem(val title: String, val date: String, val body: String)

sealed interface NewsState {
    data object Loading : NewsState
    data object NotConfigured : NewsState
    data class Loaded(val items: List<NewsItem>) : NewsState
    data class Failed(val message: String) : NewsState
}

object NewsRepository {
    /** Ожидается HTTPS-JSON-массив объектов {title, date, body}. */
    suspend fun load(url: String?): NewsState = withContext(Dispatchers.IO) {
        if (url.isNullOrBlank()) return@withContext NewsState.NotConfigured
        try {
            val array = JSONArray(HttpsClient.fetchText(url))
            NewsState.Loaded(
                List(array.length()) { i ->
                    val o = array.getJSONObject(i)
                    NewsItem(o.optString("title"), o.optString("date"), o.optString("body"))
                }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            NewsState.Failed(e.toUserMessage())
        }
    }
}
