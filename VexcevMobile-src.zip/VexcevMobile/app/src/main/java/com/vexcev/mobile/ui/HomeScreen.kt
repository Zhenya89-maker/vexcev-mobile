package com.vexcev.mobile.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vexcev.mobile.config.LauncherConfig
import com.vexcev.mobile.net.ServerStatus
import com.vexcev.mobile.news.NewsState
import com.vexcev.mobile.ui.theme.VexcevColors.Black
import com.vexcev.mobile.ui.theme.VexcevColors.Danger
import com.vexcev.mobile.ui.theme.VexcevColors.Green
import com.vexcev.mobile.ui.theme.VexcevColors.Orange
import com.vexcev.mobile.ui.theme.VexcevColors.PanelElevated
import com.vexcev.mobile.ui.theme.VexcevColors.Stroke
import com.vexcev.mobile.ui.theme.VexcevColors.TextPrimary
import com.vexcev.mobile.ui.theme.VexcevColors.TextSecondary

@Composable
fun HomeScreen(vm: LauncherViewModel, modifier: Modifier) {
    val server by vm.server.collectAsStateWithLifecycle()
    val sync by vm.sync.collectAsStateWithLifecycle()
    val news by vm.news.collectAsStateWithLifecycle()
    val playMessage by vm.playMessage.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        VexcevLogo(Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp))

        ServerPanel(server = server, onRefresh = vm::refreshServer)

        PlayPanel(
            serverReachable = server is ServerStatus.Reachable,
            gameInstalled = vm.gameClientInstalled,
            message = playMessage,
            onPlay = vm::play
        )

        ResourcesPanel(sync = sync, onSync = vm::syncResources)

        NewsPanel(news = news, onRefresh = vm::refreshNews)
    }
}

@Composable
private fun ServerPanel(server: ServerStatus, onRefresh: () -> Unit) {
    VexcevPanel {
        SectionTitle("СЕРВЕРЫ")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(LauncherConfig.SERVER_NAME, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(
                    "${LauncherConfig.SERVER_HOST}:${LauncherConfig.SERVER_PORT}",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                val (label, color) = when (server) {
                    ServerStatus.Idle -> "Не проверен" to TextSecondary
                    ServerStatus.Checking -> "Проверка…" to TextSecondary
                    is ServerStatus.Reachable -> "Доступен · ${server.latencyMs} мс" to Green
                    is ServerStatus.Unreachable -> "Недоступен" to Danger
                }
                Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Онлайн: н/д", color = TextSecondary, fontSize = 12.sp)
            }
        }
        if (server is ServerStatus.Unreachable) {
            Text(server.reason, color = TextSecondary, fontSize = 12.sp)
        }
        Text(
            "Онлайн-счётчик не отображается: протокол запроса онлайна не подключён.",
            color = TextSecondary,
            fontSize = 11.sp
        )
        TextButton(onClick = onRefresh) {
            Text("Проверить снова", color = Orange)
        }
    }
}

@Composable
private fun PlayPanel(
    serverReachable: Boolean,
    gameInstalled: Boolean,
    message: String?,
    onPlay: () -> Unit
) {
    VexcevPanel {
        Button(
            onClick = onPlay,
            enabled = gameInstalled,
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Orange,
                contentColor = Black,
                disabledContainerColor = PanelElevated,
                disabledContentColor = TextSecondary
            )
        ) {
            Text("ИГРАТЬ", fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        }
        val hint = when {
            !gameInstalled ->
                "Игровой клиент не подключён в этой сборке. Кнопка станет активной после интеграции совместимого клиента."
            !serverReachable ->
                "Сервер сейчас недоступен: запуск может не удаться."
            else -> null
        }
        hint?.let { Text(it, color = TextSecondary, fontSize = 13.sp) }
        message?.let { Text(it, color = Danger, fontSize = 13.sp) }
    }
}

@Composable
private fun ResourcesPanel(sync: SyncUi, onSync: () -> Unit) {
    VexcevPanel {
        SectionTitle("ИГРОВЫЕ РЕСУРСЫ")
        when (sync) {
            SyncUi.Idle -> Text("Проверка целостности ещё не запускалась.", color = TextSecondary, fontSize = 13.sp)
            SyncUi.NotConfigured -> Text(
                "Адрес манифеста ресурсов не задан в конфигурации. Загрузка недоступна.",
                color = TextSecondary,
                fontSize = 13.sp
            )
            is SyncUi.Running -> {
                LinearProgressIndicator(
                    progress = { sync.progress.percent / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = Orange,
                    trackColor = Stroke
                )
                Text(
                    "${sync.progress.percent}% · ${sync.progress.currentFile.ifEmpty { "подготовка…" }}" +
                        " (${sync.progress.filesDone}/${sync.progress.filesTotal})",
                    color = TextPrimary,
                    fontSize = 13.sp
                )
            }
            is SyncUi.Done -> Text(
                "Готово. Файлов: ${sync.files}, загружено заново: ${sync.downloaded}. Контрольные суммы совпадают.",
                color = Green,
                fontSize = 13.sp
            )
            is SyncUi.Failed -> Text(sync.message, color = Danger, fontSize = 13.sp)
        }
        val running = sync is SyncUi.Running
        val notConfigured = sync is SyncUi.NotConfigured
        OutlinedButton(
            onClick = onSync,
            enabled = !running && !notConfigured,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Проверить и загрузить")
        }
    }
}

@Composable
private fun NewsPanel(news: NewsState, onRefresh: () -> Unit) {
    VexcevPanel {
        SectionTitle("НОВОСТИ И ОБНОВЛЕНИЯ")
        when (news) {
            NewsState.Loading -> Text("Загрузка новостей…", color = TextSecondary, fontSize = 13.sp)
            NewsState.NotConfigured -> Text(
                "Источник новостей не настроен. Новости появятся после подключения HTTPS-ленты.",
                color = TextSecondary,
                fontSize = 13.sp
            )
            is NewsState.Failed -> Text(news.message, color = Danger, fontSize = 13.sp)
            is NewsState.Loaded -> {
                if (news.items.isEmpty()) {
                    Text("Новостей пока нет.", color = TextSecondary, fontSize = 13.sp)
                } else {
                    news.items.forEach { item ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(PanelElevated, RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Text(item.date, color = Orange, fontSize = 12.sp)
                            Text(item.title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text(item.body, color = TextSecondary, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        TextButton(onClick = onRefresh) {
            Text("Обновить", color = Orange)
        }
    }
}
