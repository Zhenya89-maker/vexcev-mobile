package com.vexcev.mobile

import android.app.Application

class VexcevApp : Application()
