package com.vexcev.mobile.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vexcev.mobile.ui.theme.VexcevColors.Black
import com.vexcev.mobile.ui.theme.VexcevColors.Orange
import com.vexcev.mobile.ui.theme.VexcevColors.TextPrimary
import com.vexcev.mobile.ui.theme.VexcevColors.TextSecondary

@Composable
fun ProfileScreen(vm: LauncherViewModel, modifier: Modifier) {
    val nickname by vm.nickname.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        VexcevPanel {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Orange),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = nickname.trim().firstOrNull()?.uppercase() ?: "?",
                        color = Black,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Column {
                    Text(
                        text = nickname.trim().ifEmpty { "Игрок без имени" },
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 18.sp
                    )
                    Text("Профиль лаунчера", color = TextSecondary, fontSize = 13.sp)
                }
            }
        }

        VexcevPanel {
            SectionTitle("ИГРОВОЙ НИК")
            OutlinedTextField(
                value = nickname,
                onValueChange = vm::setNickname,
                singleLine = true,
                label = { Text("Никнейм (до 16 символов)") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Orange,
                    focusedLabelColor = Orange,
                    cursorColor = Orange
                )
            )
            Text(
                "Статистика и привязка аккаунта появятся после подключения серверного API. Сейчас эти данные не запрашиваются.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
    }
}
