package com.vexcev.mobile.net

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

sealed interface ServerStatus {
    data object Idle : ServerStatus
    data object Checking : ServerStatus
    data class Reachable(val latencyMs: Long) : ServerStatus
    data class Unreachable(val reason: String) : ServerStatus
}

/**
 * Проверяет, принимает ли сервер TCP-соединения на указанном порту.
 *
 * Важно: это проверка доступности порта, а не подтверждение работы игры.
 * Успешное соединение не означает, что игровой клиент подключён.
 */
class ServerChecker(
    private val host: String,
    private val port: Int,
    private val timeoutMs: Int
) {
    suspend fun check(): ServerStatus = withContext(Dispatchers.IO) {
        val started = System.nanoTime()
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            ServerStatus.Reachable((System.nanoTime() - started) / 1_000_000L)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ServerStatus.Unreachable(e.toUserMessage())
        }
    }
}
