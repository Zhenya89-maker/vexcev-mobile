package com.vexcev.mobile.game

sealed interface LaunchResult {
    data object Started : LaunchResult
    data class Unavailable(val reason: String) : LaunchResult
}

/**
 * Интерфейс интеграции игрового клиента.
 * Реальная реализация подключается только при наличии совместимого клиента
 * с исходниками и документацией. До этого используется NoGameClient.
 */
interface GameClient {
    val isInstalled: Boolean
    fun launch(host: String, port: Int, nickname: String): LaunchResult
}

/** Заглушка без имитации запуска: честно сообщает, что клиент не подключён. */
object NoGameClient : GameClient {
    override val isInstalled: Boolean = false

    override fun launch(host: String, port: Int, nickname: String): LaunchResult =
        LaunchResult.Unavailable(
            "Совместимый игровой клиент не подключён в этой сборке. Запуск не выполнен."
        )
}
