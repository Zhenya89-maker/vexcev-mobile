package com.vexcev.mobile.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object VexcevColors {
    val Black = Color(0xFF000000)
    val Panel = Color(0xFF121212)
    val PanelElevated = Color(0xFF1C1C1C)
    val Stroke = Color(0xFF2A2A2A)
    val Orange = Color(0xFFFF7A1A)
    val TextPrimary = Color(0xFFF2F2F2)
    val TextSecondary = Color(0xFF9A9A9A)
    val Green = Color(0xFF3DDC84)
    val Danger = Color(0xFFFF4D4D)
}

private val DarkScheme = darkColorScheme(
    primary = VexcevColors.Orange,
    onPrimary = VexcevColors.Black,
    background = VexcevColors.Black,
    onBackground = VexcevColors.TextPrimary,
    surface = VexcevColors.Panel,
    onSurface = VexcevColors.TextPrimary,
    surfaceVariant = VexcevColors.PanelElevated,
    onSurfaceVariant = VexcevColors.TextSecondary,
    outline = VexcevColors.Stroke,
    error = VexcevColors.Danger
)

@Composable
fun VexcevTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
