package com.vexcev.mobile.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vexcev.mobile.config.LauncherConfig
import com.vexcev.mobile.game.GameClient
import com.vexcev.mobile.game.LaunchResult
import com.vexcev.mobile.game.NoGameClient
import com.vexcev.mobile.net.ServerChecker
import com.vexcev.mobile.net.ServerStatus
import com.vexcev.mobile.news.NewsRepository
import com.vexcev.mobile.news.NewsState
import com.vexcev.mobile.resources.ResourceSync
import com.vexcev.mobile.resources.SyncProgress
import com.vexcev.mobile.resources.SyncResult
import com.vexcev.mobile.settings.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface SyncUi {
    data object Idle : SyncUi
    data object NotConfigured : SyncUi
    data class Running(val progress: SyncProgress) : SyncUi
    data class Done(val files: Int, val downloaded: Int) : SyncUi
    data class Failed(val message: String) : SyncUi
}

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = SettingsStore(app)
    private val gameClient: GameClient = NoGameClient
    private val resourceSync = ResourceSync(File(app.filesDir, "game"))
    private val serverChecker = ServerChecker(
        LauncherConfig.SERVER_HOST,
        LauncherConfig.SERVER_PORT,
        LauncherConfig.CONNECT_TIMEOUT_MS
    )

    private val _server = MutableStateFlow<ServerStatus>(ServerStatus.Idle)
    val server: StateFlow<ServerStatus> = _server.asStateFlow()

    private val _sync = MutableStateFlow<SyncUi>(SyncUi.Idle)
    val sync: StateFlow<SyncUi> = _sync.asStateFlow()

    private val _news = MutableStateFlow<NewsState>(NewsState.Loading)
    val news: StateFlow<NewsState> = _news.asStateFlow()

    private val _playMessage = MutableStateFlow<String?>(null)
    val playMessage: StateFlow<String?> = _playMessage.asStateFlow()

    private val _nickname = MutableStateFlow(settings.nickname)
    val nickname: StateFlow<String> = _nickname.asStateFlow()

    private val _verifyOnStart = MutableStateFlow(settings.verifyOnStart)
    val verifyOnStart: StateFlow<Boolean> = _verifyOnStart.asStateFlow()

    private val _checkServerOnStart = MutableStateFlow(settings.checkServerOnStart)
    val checkServerOnStart: StateFlow<Boolean> = _checkServerOnStart.asStateFlow()

    val gameClientInstalled: Boolean get() = gameClient.isInstalled

    init {
        if (settings.checkServerOnStart) refreshServer()
        refreshNews()
        if (settings.verifyOnStart) syncResources()
    }

    fun refreshServer() {
        viewModelScope.launch {
            _server.value = ServerStatus.Checking
            _server.value = serverChecker.check()
        }
    }

    fun syncResources() {
        if (_sync.value is SyncUi.Running) return
        viewModelScope.launch {
            _sync.value = SyncUi.Running(SyncProgress(0, "", 0, 0))
            val result = resourceSync.run(LauncherConfig.RESOURCE_MANIFEST_URL) { progress ->
                _sync.value = SyncUi.Running(progress)
            }
            _sync.value = when (result) {
                SyncResult.NotConfigured -> SyncUi.NotConfigured
                is SyncResult.Ok -> SyncUi.Done(result.files, result.downloaded)
                is SyncResult.Failed -> SyncUi.Failed(result.message)
            }
        }
    }

    fun refreshNews() {
        viewModelScope.launch {
            _news.value = NewsState.Loading
            _news.value = NewsRepository.load(LauncherConfig.NEWS_URL)
        }
    }

    fun play() {
        _playMessage.value = when (
            val result = gameClient.launch(
                LauncherConfig.SERVER_HOST,
                LauncherConfig.SERVER_PORT,
                _nickname.value
            )
        ) {
            LaunchResult.Started -> null
            is LaunchResult.Unavailable -> result.reason
        }
    }

    fun setNickname(value: String) {
        settings.nickname = value
        _nickname.value = settings.nickname
    }

    fun setVerifyOnStart(enabled: Boolean) {
        settings.verifyOnStart = enabled
        _verifyOnStart.value = enabled
    }

    fun setCheckServerOnStart(enabled: Boolean) {
        settings.checkServerOnStart = enabled
        _checkServerOnStart.value = enabled
    }
}
