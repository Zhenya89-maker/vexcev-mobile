package com.vexcev.mobile

import com.vexcev.mobile.net.LauncherException
import com.vexcev.mobile.resources.ManifestParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ManifestParserTest {

    private val validSha = "a".repeat(64)

    @Test
    fun parsesValidManifest() {
        val json = """{"files":[{"path":"data/a.bin","url":"https://example.com/a.bin","sha256":"$validSha","size":10}]}"""
        val entries = ManifestParser.parse(json)
        assertEquals(1, entries.size)
        assertEquals("data/a.bin", entries[0].path)
    }

    @Test
    fun rejectsHttpUrl() {
        val json = """{"files":[{"path":"a.bin","url":"http://example.com/a.bin","sha256":"$validSha","size":10}]}"""
        assertThrows(LauncherException::class.java) { ManifestParser.parse(json) }
    }

    @Test
    fun rejectsPathTraversal() {
        val json = """{"files":[{"path":"../evil.bin","url":"https://example.com/x","sha256":"$validSha","size":1}]}"""
        assertThrows(LauncherException::class.java) { ManifestParser.parse(json) }
    }

    @Test
    fun rejectsBadChecksum() {
        val json = """{"files":[{"path":"a.bin","url":"https://example.com/a","sha256":"xyz","size":1}]}"""
        assertThrows(LauncherException::class.java) { ManifestParser.parse(json) }
    }
}
